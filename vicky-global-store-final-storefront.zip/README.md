# Vicky Global Store
Premium phone + fashion storefront for Aba, Nigeria.

## Current setup
- Brand: Vicky Global Store
- WhatsApp: 0810 042 0541
- Bank: Globus Bank
- Account name: Eze Atufunwa
- Account number: 4736825683
- Sample phone prices: ₦70,000–₦95,000
- Sample clothing prices: under ₦20,000

## Important
The catalog currently contains clearly marked sample listings. Replace them with the friend's real products, exact prices, stock, and photos before publishing.

## Deploy
Upload `index.html` to a GitHub repository and import it into Vercel, or deploy the folder as a static site.
